import yfinance as yf
# msft = yf.Ticker("MSFT")
# print(yf.Ticker("MSFT").info)
ticker=yf.Ticker("MSFT").info
ticker['esg_scores']