# from langchain.document_loaders import UnstructuredPowerPointLoader

# loader = UnstructuredPowerPointLoader(
#     "template.pptx", mode="elements", strategy="fast",
# )
# docs = loader.load()

# print(docs)

from pptx import Presentation
from langchain.llms import OpenAI

# Load the PowerPoint file
ppt_path = 'template_full.pptx'
ppt = Presentation(ppt_path)

llm = OpenAI(temperature=0.9)

# Iterate through all slides and text frames to find and replace the text
for slide in ppt.slides:
    for shape in slide.shapes:
        if shape.has_text_frame:
            for paragraph in shape.text_frame.paragraphs:
                for run in paragraph.runs:
                    if run.text.startswith("Prompt"):
                        print (run.text)
#                         run.text = llm(run.text)
#                         print (run.text)

# modified_ppt_path = 'modified_template.pptx'
# ppt.save(modified_ppt_path)