from pptx import Presentation
from pptx.util import Inches
import io

# Load the PowerPoint presentation
pptx_path = 'template_test.pptx'
presentation = Presentation(pptx_path)

# Load the image to be inserted
image_png_path = 'Volkswagen_Logo.png'

# Retry adding the image with the converted PNG format
presentation = Presentation(pptx_path)  # Reload the original presentation to start fresh

# Iterate through shapes in the first slide to find the first textbox
for shape in presentation.slides[0].shapes:
    if shape.has_text_frame:
        # Get the position and size of the textbox
        left = shape.left
        top = shape.top
        width = shape.width
        height = shape.height

        # Delete the textbox
        sp = shape._element
        sp.getparent().remove(sp)

        # Add the converted PNG image with the same size and position as the textbox
        presentation.slides[0].shapes.add_picture(image_png_path, left, top, width, height)
        break  # Assuming we only replace the first found textbox

modified_pptx_path_converted = 'modified_template_test_converted.pptx'
presentation.save(modified_pptx_path_converted)

modified_pptx_path_converted