# from langchain.agents import load_tools, initialize_agent
# from langchain.agents import AgentType

# from langchain.python import PythonREPL
# from langchain.chat_models import ChatOpenAI
# from langchain.agents import tool
# from datetime import date
# @tool
# def time(text: str) -> str:
#     """
#     返回今天的日期，用于任何需要知道今天日期的问题。\
#     输入应该总是一个空字符串，\
#     这个函数将总是返回今天的日期，任何日期计算应该在这个函数之外进行。
#     """
#     return str(date.today())
# llm = ChatOpenAI(temperature=0)
# # 初始化代理
# agent= initialize_agent(
#     tools=[time], #将刚刚创建的时间工具加入代理
#     llm=llm, #初始化的模型
#     agent=AgentType.CHAT_ZERO_SHOT_REACT_DESCRIPTION, #代理类型
#     handle_parsing_errors=True, #处理解析错误
#     verbose = True #输出中间步骤
# )
# # 使用代理询问今天的日期.
# # 注: 代理有时候可能会出错（该功能正在开发中）。如果出现错误，请尝试再次运行它。
# agent("今天的日期是？")

from langchain.llms import OpenAI
llm = OpenAI(temperature=0.9)
text = "Prompt: enter a random  topic title related to AWS"
print(llm(text))